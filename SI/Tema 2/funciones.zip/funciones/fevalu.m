function cont=fevalu(Actual)
   %% eval�a Actual
   cont=0;
   for i=1:length(Actual)-1
       for j=i+1:length(Actual)
           cont=cont+( abs(Actual(i)-Actual(j))==abs(i-j));
       end
   end
end