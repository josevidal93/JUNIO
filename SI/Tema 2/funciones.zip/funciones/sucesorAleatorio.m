function s=sucesorAleatorio(Actual)
    [val,ind]=sort(rand(1,length(Actual)));
    a=ind(1); b=ind(2);    
    
    aux=Actual(a);
    Actual(a)=Actual(b);
    Actual(b)=aux;
    s=Actual;
end
